﻿using Microsoft.Xna.Framework.Graphics;
using Sprint_4.States.PowerupStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_4.States.Action_States
{
    interface IActionState : IStates
    {
        IActionState MoveLeft(ref bool leftFacing);
        IActionState MoveRight(ref bool leftFacing);
        IActionState Jump();
        IActionState Crouch(IPowerupState currentPowerupState);
        IActionState Fall();
        IActionState Exit();
    }
}
