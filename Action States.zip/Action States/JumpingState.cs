﻿using Microsoft.Xna.Framework.Graphics;
using Sprint_4.States.PowerupStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_4.States.Action_States
{
    class JumpingState : IActionState

    {
        private static JumpingState instance = null;

        public IActionState prevState;
        private JumpingState()
        {
        }

        public static JumpingState Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new JumpingState();
                }
                return instance;
            }
        }
        public IActionState Crouch(IPowerupState currentPowerupState)
        {
            return this.prevState;
        }

        public IActionState Jump()
        {
            return this;
        }

        public IActionState MoveLeft(ref bool leftFacing)
        {
            leftFacing = true;
            return this;
        }

        public IActionState MoveRight(ref bool leftFacing)
        {
            leftFacing = false;
            return this;
        }
        public IActionState Fall()
        {
            return this;
        }
        public void Update()
        {
            throw new NotImplementedException();
        }
        public IActionState Exit()
        {
            return new IdlingState();
        }
    }
}
