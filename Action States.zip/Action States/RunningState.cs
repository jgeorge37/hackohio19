﻿using Microsoft.Xna.Framework.Graphics;
using Sprint_4.States.PowerupStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_4.States.Action_States
{
    class RunningState : IActionState
    {
        private static RunningState instance = null;
        private RunningState()
        {
        }

        public static RunningState Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new RunningState();
                }
                return instance;
            }
        }
        public IActionState Crouch(IPowerupState currentPowerupState)
        {
            if (currentPowerupState is StandardState)
            {
                return this;
            }
            else
            {
                CrouchingState.Instance.prevState = this;
                return CrouchingState.Instance;
            }
        }

        public IActionState Jump()
        {
            JumpingState.Instance.prevState = this;
            return JumpingState.Instance;
        }

        public IActionState MoveLeft(ref bool leftFacing)
        {
            if (leftFacing)
            {
                return this;
            }
            else
            {
                return IdlingState.Instance;
            }
        }

        public IActionState MoveRight(ref bool leftFacing)
        {
            if (leftFacing)
            {
                return IdlingState.Instance;
            }
            else
            {
                return this;
            }
        }
        public IActionState Fall()
        {
            return FallingState.Instance;
        }
        public void Update()
        {
            throw new NotImplementedException();
        }
        public IActionState Exit()
        {
            throw new NotImplementedException();
        }
    }
}
