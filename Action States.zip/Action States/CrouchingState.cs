﻿using Microsoft.Xna.Framework.Graphics;
using Sprint_4.States.PowerupStates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sprint_4.States.Action_States
{
    class CrouchingState : IActionState
    {
        private static CrouchingState instance = null;
        private CrouchingState()
        {
        }

        public IActionState prevState;

        public static CrouchingState Instance
        {

            get
            {
                if (instance == null)
                {
                    instance = new CrouchingState();
                }
                return instance;
            }
        }

        public IActionState Crouch(IPowerupState currentPowerupState)
        {
            return this;
        }

        public IActionState Jump()
        {
            return this.prevState;
        }

        public IActionState MoveLeft(ref bool leftFacing)
        {
            return Exit();
        }

        public IActionState MoveRight(ref bool leftFacing)
        {
            return Exit();
        }
        public IActionState Fall()
        {
            return new FallingState();
        }
        public IActionState Exit()
        {
            return new IdlingState();
        }
        public void Update()
        {
            throw new NotImplementedException();
        }
    }
}
